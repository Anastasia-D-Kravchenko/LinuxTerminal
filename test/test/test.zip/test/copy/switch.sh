#!/bin/bash

case "$1" in
	"1")
		echo "one";;
	"2")
		echo "two";;
	*)
		echo "Da hyi znaet";;
esac
